// ===== AUREX FILMS — SCRIPT =====
// Handles: mobile menu, sticky nav, portfolio filters, video previews,
// scroll-in animations and the footer year. No libraries needed.

document.documentElement.classList.remove("no-js");
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// --- Mobile menu ---
const toggle = document.querySelector(".nav__toggle");
const menu = document.getElementById("nav-menu");
function setMenu(open) {
  menu.classList.toggle("is-open", open);
  toggle.setAttribute("aria-expanded", String(open));
  toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
}
toggle.addEventListener("click", () => setMenu(!menu.classList.contains("is-open")));
menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setMenu(false)));
document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });

// --- Nav background on scroll ---
const nav = document.querySelector(".nav");
const onScroll = () => nav.classList.toggle("is-scrolled", window.scrollY > 40);
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();

// --- Portfolio filters ---
const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".card");
const emptyMsg = document.getElementById("empty-msg");
filters.forEach((btn) => {
  btn.addEventListener("click", () => {
    const cat = btn.dataset.filter;
    filters.forEach((b) => {
      b.classList.toggle("is-active", b === btn);
      b.setAttribute("aria-pressed", String(b === btn));
    });
    let shown = 0;
    cards.forEach((card) => {
      const match = cat === "all" || card.dataset.category === cat;
      card.classList.toggle("is-hidden", !match);
      if (match) { shown++; card.classList.add("is-visible"); }
    });
    emptyMsg.hidden = shown > 0;
  });
});

// --- Video previews: play on hover (desktop) or when visible (phones) ---
document.querySelectorAll(".card video").forEach((video) => {
  const card = video.closest(".card");
  if (reduceMotion) return; // poster image only
  card.addEventListener("mouseenter", () => video.play().catch(() => {}));
  card.addEventListener("mouseleave", () => video.pause());
  if (window.matchMedia("(hover: none)").matches) {
    new IntersectionObserver(([entry]) => {
      entry.isIntersecting ? video.play().catch(() => {}) : video.pause();
    }, { threshold: 0.6 }).observe(video);
  }
});
if (reduceMotion) document.querySelector(".hero__bg")?.pause();

// --- Scroll-in animations ---
const reveals = document.querySelectorAll(".reveal");
if (reduceMotion || !("IntersectionObserver" in window)) {
  reveals.forEach((el) => el.classList.add("is-visible"));
} else {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); io.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  reveals.forEach((el) => io.observe(el));
}

// --- Footer year ---
document.getElementById("year").textContent = new Date().getFullYear();
