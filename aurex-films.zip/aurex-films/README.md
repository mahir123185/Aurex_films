# Aurex Films — Portfolio Website

Plain HTML, CSS and JavaScript. No installs, no build step.

```
index.html   ← page content (text, projects, contact links)
style.css    ← colours, fonts, layout
script.js    ← mobile menu, filters, animations
assets/      ← your images and videos
```

## 1. Replace the placeholders
Search `index.html` for **REPLACE** comments and update:
- WhatsApp: `https://wa.me/15551234567` → your number with country code, no `+` or spaces (e.g. `https://wa.me/919876543210`)
- Instagram: `https://instagram.com/aurexfilms` → your username
- Phone: `tel:+15551234567` → your number
- Project titles, alt text and media files in the portfolio grid

## 2. Publish on GitHub Pages
1. Sign in at github.com → **New repository** → name it e.g. `aurex-films` → Public → Create.
2. Click **Add file → Upload files**, drag in `index.html`, `style.css`, `script.js`, `README.md` and the whole `assets` folder. Click **Commit changes**.
3. Go to **Settings → Pages**. Under *Source* choose **Deploy from a branch**, branch **main**, folder **/ (root)** → Save.
4. Wait 1–2 minutes. Your site will be live at `https://YOUR-USERNAME.github.io/aurex-films/`.

## 3. Add your own images and videos
This site has **no upload system** — you add work by uploading files to GitHub:
1. Prepare the file:
   - Images: JPG or WebP, about **1280×800 px**, under **300 KB** (compress free at squoosh.app or tinypng.com).
   - Videos: MP4 (H.264), **5–15 seconds**, 720p, no audio, under **3–5 MB** (HandBrake is free). GitHub rejects files over 100 MB.
   - Use simple names: lowercase, dashes, no spaces — `bmw-delivery.jpg`.
2. In your repository open the `assets` folder → **Add file → Upload files** → Commit.
3. In `index.html` (click the file → pencil icon), copy an `<article class="card">` block and change:
   - `data-category` → `reels`, `photo`, `templates` or `logos` (controls the filters)
   - `src="assets/your-file.jpg"` (and `poster`/`source` for videos)
   - `alt="..."` → describe what's in the image
   - the label and the `<h3>` title
4. Commit. The live site updates in about a minute.

**Image card**
```html
<article class="card reveal" data-category="photo">
  <div class="card__media">
    <img src="assets/my-photo.jpg" alt="Describe the photo" loading="lazy" width="1280" height="800" />
  </div>
  <div class="card__body">
    <span class="card__label">Photo Edits</span>
    <h3>My Project Title</h3>
  </div>
</article>
```

**Video card** (plays on hover; `poster` is the still image shown first)
```html
<article class="card reveal" data-category="reels">
  <div class="card__media">
    <video muted loop playsinline preload="none" poster="assets/my-thumb.jpg" aria-label="Describe the video">
      <source src="assets/my-reel.mp4" type="video/mp4" />
    </video>
    <span class="card__badge">▶ Video</span>
  </div>
  <div class="card__body">
    <span class="card__label">Reels &amp; Films</span>
    <h3>My Reel Title</h3>
  </div>
</article>
```

Tip: for long full-length videos, upload them to YouTube/Instagram and keep only a short preview clip on the site.

## Change the colours
At the top of `style.css`, edit `--accent` (the amber colour) or `--bg` (background).
